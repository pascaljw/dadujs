/*
    1. Tuliskan seluruh kode Java Script Anda di sini
    2. Semua file di project ini TIDAK PERLU diubah, selain file ini
    3. Pastikan program anda rapi, terstruktur dengan baik, dan mudah dibaca
*/
